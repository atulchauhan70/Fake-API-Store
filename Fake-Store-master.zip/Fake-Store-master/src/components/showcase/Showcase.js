import React from "react";

const Showcase = () => {
  return (
    <div className="text-center bg-secondary" style={{ height: "50vh" }}>
      SHOW CASE
    </div>
  );
};

export default Showcase;
